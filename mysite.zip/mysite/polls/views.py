# -*- coding: utf-8 -*-

# Create your views here.
from django.shortcuts import get_object_or_404, render
from django.http import HttpResponseRedirect
from django.core.urlresolvers import reverse
from django.views import generic
from django.db.models import Sum
from .models import Choice, Question


class IndexView(generic.ListView):
    template_name = 'polls/index.html'
    context_object_name = 'latest_question_list'

    def get_queryset(self):
        """Zeruje pole votes dla odpowiedzi """
        for i in range(1, Choice.objects.count()):
            t = Choice.objects.get(id=i)
            t.votes = 0
            t.save()

        """Wyświetla pytania od najnowszego do najstarszego - pierwsze pytanie """

        return Question.objects.order_by('-pub_date')[:1]


class DetailView(generic.DetailView):
    model = Question
    template_name = 'polls/detail.html'


class ResultsView(generic.DetailView):
    model = Question
    template_name = 'polls/results.html'

    def get_res(self):
        question = self.get_object()
        for choice in question.choice_set.all():
            if choice.votes :
                return True
        return False
        #return self.kwargs['res']


    def wynik_procentowy(self):
        return (float(Choice.objects.all().aggregate(wynik=Sum('votes'))['wynik'])/float(Question.objects.count()))*100

    def wynik_koncowy(self):
            return (Choice.objects.all().aggregate(wynik=Sum('votes'))['wynik'])


def vote(request, question_id):
    question = get_object_or_404(Question, pk=question_id)
    try:
        selected_choice = question.choice_set.get(pk=request.POST['choice'])
    except (KeyError, Choice.DoesNotExist):
        # Redisplay the question voting form.
        return render(request, 'polls/detail.html', {
            'question': question,
            'error_message': "Proszę wybrać odpowiedź",
        })
    else:
        res = 0
        if selected_choice.answer:
            selected_choice.votes = 1
            selected_choice.save()
            res = 1
        # Always return an HttpResponseRedirect after successfully dealing
        # with POST data. This prevents data from being posted twice if a
        # user hits the Back button.
        return HttpResponseRedirect(reverse('polls:results', args=(question.id,)))
        #return HttpResponseRedirect(reverse('polls:results', kwargs={'pk':question.id, 'res':res}))
